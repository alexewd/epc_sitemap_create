# epc_sitemap_create
WP plugin - create sitemap.xml file.

Download zip file, select - add new plugin, install and activate.
That's all.
